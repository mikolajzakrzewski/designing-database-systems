import React, { useState } from 'react';
import { Calendar, MapPin, Users, Mountain, Star, Trophy, Target, Compass } from 'lucide-react';

import './Events.css'; 


import expedition1 from '../assets/expedition1.jpg';
import expedition2 from '../assets/expedition2.jpeg';
import expedition3 from '../assets/expedition3.jpeg';
import competition1 from '../assets/competition1.jpeg';
import competition2 from '../assets/competition2.jpg';
import training1 from '../assets/training1.jpeg';
import training2 from '../assets/training2.jpg';
import training3 from '../assets/training3.jpeg';


const Events = () => {
  const [currentPage, setCurrentPage] = useState('events');
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [formData, setFormData] = useState({
    participationType: '',
  });

  const events = [
    // EXPEDITIONS
    {
      id: 1,
      type: 'expedition',
      title: "Alpine Adventure Weekend",
      date: "June 15-16, 2025",
      location: "Rocky Mountain National Park",
      difficulty: "Intermediate",
      participants: 12,
      maxParticipants: 15,
      price: "$285",
      image: expedition1,
      description: "Two-day alpine climbing experience with certified guides. Perfect for those looking to advance their outdoor climbing skills.",
      includes: ["Professional guide", "Safety equipment", "Group meals", "Camping gear"],
      // Expedition specific data
      mountainChain: "Rocky Mountains",
      expeditionId: "EXP001"
    },
    {
      id: 4,
      type: 'expedition',
      title: "Multi-Pitch Mastery",
      date: "July 12-14, 2025",
      location: "Yosemite Valley",
      difficulty: "Advanced",
      participants: 6,
      maxParticipants: 8,
      price: "$450",
      image: expedition2,
      description: "Advanced 3-day course focusing on multi-pitch climbing techniques, anchor building, and route finding in iconic Yosemite.",
      includes: ["Expert instruction", "Technical gear", "3 days camping", "All meals"],
      // Expedition specific data
      mountainChain: "Sierra Nevada",
      expeditionId: "EXP002"
    },
    {
      id: 6,
      type: 'expedition',
      title: "Night Climbing Experience",
      date: "July 19, 2025",
      location: "Red Rock Canyon",
      difficulty: "Intermediate",
      participants: 10,
      maxParticipants: 14,
      price: "$125",
      image: expedition3,
      description: "Unique night climbing experience under the stars. Headlamp-lit adventure with spectacular desert views.",
      includes: ["Headlamps provided", "Night gear", "Hot beverages", "Transportation"],
      // Expedition specific data
      mountainChain: "Mojave Desert",
      expeditionId: "EXP003"
    },
    
    // COMPETITIONS
    {
      id: 2,
      type: 'competition',
      title: "Indoor Competition Series",
      date: "July 8, 2025",
      location: "Vertical Limits Gym",
      difficulty: "All Levels",
      participants: 28,
      maxParticipants: 40,
      price: "$45",
      image: competition1,
      description: "Monthly indoor climbing competition with different categories for all skill levels. Prizes for top performers!",
      includes: ["Day pass", "Competition entry", "T-shirt", "Post-event social"],
      // Competition specific data
      rank: "Regional Championship",
      rewardPool: 2500.00,
      discipline: "Sport Climbing - Lead & Boulder",
      competitionId: "COMP001"
    },
    {
      id: 7,
      type: 'competition',
      title: "Bouldering Championship",
      date: "August 15, 2025",
      location: "Summit Climbing Center",
      difficulty: "Intermediate to Advanced",
      participants: 35,
      maxParticipants: 50,
      price: "$65",
      image: competition2,
      description: "Annual bouldering competition featuring challenging routes and exciting prizes for all categories.",
      includes: ["Competition entry", "Professional judging", "Awards ceremony", "Competitor t-shirt"],
      // Competition specific data
      rank: "State Championship",
      rewardPool: 5000.00,
      discipline: "Bouldering",
      competitionId: "COMP002"
    },
    
    // TRAININGS
    {
      id: 3,
      type: 'training',
      title: "Beginner's Rock Course",
      date: "June 22-23, 2025",
      location: "Garden of the Gods",
      difficulty: "Beginner",
      participants: 8,
      maxParticipants: 12,
      price: "$195",
      image: training1,
      description: "Perfect introduction to outdoor rock climbing. Learn essential techniques, safety protocols, and gain confidence on real rock.",
      includes: ["2-day instruction", "All climbing gear", "Certification", "Lunch both days"],
      // Training specific data
      trainingType: "Basic Rock Climbing",
      trainingId: "TRN001"
    },
    {
      id: 5,
      type: 'training',
      title: "Youth Climbing Camp",
      date: "August 5-9, 2025",
      location: "Local Climbing Gym + Outdoor",
      difficulty: "Youth (8-16)",
      participants: 15,
      maxParticipants: 20,
      price: "$320",
      image: training2,
      description: "Week-long climbing camp for young adventurers. Mix of indoor and outdoor climbing with focus on fun and skill development.",
      includes: ["5 days instruction", "Equipment provided", "Daily snacks", "Camp t-shirt"],
      // Training specific data
      trainingType: "Youth Development Program",
      trainingId: "TRN002"
    },
    {
      id: 8,
      type: 'training',
      title: "Advanced Rescue Techniques",
      date: "September 10-11, 2025",
      location: "Mountain Rescue Training Center",
      difficulty: "Advanced",
      participants: 6,
      maxParticipants: 10,
      price: "$380",
      image: training3,
      description: "Intensive training in climbing rescue techniques, emergency response, and risk management for experienced climbers.",
      includes: ["Expert instruction", "Rescue equipment", "Certification", "Training materials"],
      // Training specific data
      trainingType: "Emergency Response & Rescue",
      trainingId: "TRN003"
    }
  ];

  const handleRegister = (event) => {
    setSelectedEvent(event);
    setCurrentPage('registration');
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const simulatePayment = () => {
  setCurrentPage('payu');
  setTimeout(() => {
    alert(`Payment successful! Thank you ${formData.firstName} ${formData.lastName}.`);
    setCurrentPage('events');
    setFormData({
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      participationType: '',
      emergencyContact: '',
      emergencyPhone: '',
      dietaryRestrictions: '',
      comments: ''
    });
    setSelectedEvent(null);
  }, 3000); // 3 sekundy
};


  const handleSubmit = () => {
    // Basic validation
    if (!formData.participationType) {
      alert('Please fill in all required fields.');
      return;
    }
    
    if (!selectedEvent) {
      alert('No event selected.');
      return;
    }
    
    alert(`Registration submitted for ${selectedEvent.title}!\n\nThank you ${formData.firstName} ${formData.lastName}, we'll contact you at ${formData.email} with further details.`);
    
    // Reset form
    setFormData({
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      participationType: '',
      emergencyContact: '',
      emergencyPhone: '',
      dietaryRestrictions: '',
      comments: ''
    });
    setCurrentPage('events');
  };

  const getDifficultyColor = (difficulty) => {
    switch (difficulty.toLowerCase()) {
      case 'beginner': return 'difficulty-beginner';
      case 'intermediate': return 'difficulty-intermediate';
      case 'advanced': return 'difficulty-advanced';
      default: return 'difficulty-default';
    }
  };

  const getTypeIcon = (type) => {
    switch (type) {
      case 'expedition': return <Compass className="type-icon" />;
      case 'competition': return <Trophy className="type-icon" />;
      case 'training': return <Target className="type-icon" />;
      default: return <Mountain className="type-icon" />;
    }
  };

  const getTypeColor = (type) => {
    switch (type) {
      case 'expedition': return 'type-expedition';
      case 'competition': return 'type-competition';
      case 'training': return 'type-training';
      default: return 'type-default';
    }
  };

  const renderEventSpecificInfo = (event) => {
    switch (event.type) {
      case 'expedition':
        return (
          <div className="specific-info">
            <div className="event-detail">
              <Mountain className="icon" />
              <span>Mountain Chain: {event.mountainChain}</span>
            </div>
            <div className="event-detail">
              <Compass className="icon" />
              <span>Expedition ID: {event.expeditionId}</span>
            </div>
          </div>
        );
      case 'competition':
        return (
          <div className="specific-info">
            <div className="event-detail">
              <Trophy className="icon" />
              <span>Rank: {event.rank}</span>
            </div>
            <div className="event-detail">
              <Star className="icon" />
              <span>Prize Pool: ${event.rewardPool}</span>
            </div>
            <div className="event-detail">
              <Target className="icon" />
              <span>Discipline: {event.discipline}</span>
            </div>
          </div>
        );
      case 'training':
        return (
          <div className="specific-info">
            <div className="event-detail">
              <Target className="icon" />
              <span>Training: {event.trainingType}</span>
            </div>
            <div className="event-detail">
              <Users className="icon" />
              <span>Training ID: {event.trainingId}</span>
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  if (currentPage === 'payu') {
  return (
    <div className="app-container">
      <div className="payment-simulation">
        <h1>Redirecting to PayU...</h1>
        <p>Please wait while we process your payment.</p>
        <div className="loader"></div>
      </div>
    </div>
  );
}


  // Registration Page
  if (currentPage === 'registration' && selectedEvent) {
    return (
      <div className="app-container">
        <div className="registration-container">
          <div className="registration-wrapper">
            <button 
              onClick={() => setCurrentPage('events')}
              className="back-button"
              type="button"
            >
              ← Back to Events
            </button>
            
            <div className="registration-card">
              <div className="registration-header">
                <h1>Event Registration</h1>
                <p>Register for: {selectedEvent.title}</p>
                <div className={`event-type-badge ${getTypeColor(selectedEvent.type)}`}>
                  {getTypeIcon(selectedEvent.type)}
                  <span>{selectedEvent.type.toUpperCase()}</span>
                </div>
              </div>
              
              <div className="registration-content">
                <div className="event-summary">
                  <h2>{selectedEvent.title}</h2>
                  <div className="event-details-grid">
                    <div className="event-detail">
                      <Calendar className="icon" />
                      <span>{selectedEvent.date}</span>
                    </div>
                    <div className="event-detail">
                      <MapPin className="icon" />
                      <span>{selectedEvent.location}</span>
                    </div>
                    <div className="event-detail">
                      <Users className="icon" />
                      <span>Price: {selectedEvent.price}</span>
                    </div>
                    <div className="event-detail">
                      <Mountain className="icon" />
                      <span>{selectedEvent.difficulty}</span>
                    </div>
                  </div>
                  {renderEventSpecificInfo(selectedEvent)}
                </div>

                <div className="registration-form">
                  
                  

                  

                  <div className="form-group">
                    <label>Participation Type *</label>
                    <select
                      name="participationType"
                      required
                      value={formData.participationType}
                      onChange={handleInputChange}
                    >
                      <option value="">Select your participation type</option>
                      <option value="participant">Participant</option>
                      <option value="coach">Coach</option>
                      <option value="judge">Judge</option>
                    </select>
                  </div>

                  

                  <div className="form-actions">
                    <button
                      type="button"
                      onClick={() => setCurrentPage('events')}
                      className="btn-secondary"
                    >
                      Cancel
                    </button>
                    <button
  type="button"
  className="btn-primary"
  onClick={simulatePayment}
>
  Pay Now
</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Events Overview Page
  return (
    <div className="app-container">
      {/* Header */}
      <div className="hero-section">
        <div className="hero-content">
          <h1 className="hero-title">
            <Mountain className="hero-icon" />
            Polish Climbing Association Events
          </h1>
          <p className="hero-subtitle">
            Join our thrilling climbing events and take your adventure to new heights. 
            From beginner trainings to advanced expeditions and competitive events.
          </p>
        </div>
      </div>

      {/* Events Grid */}
      <div className="events-section">
        <div className="section-header">
          <h2>Upcoming Events</h2>
          <p>
            Choose from our carefully crafted climbing experiences: expeditions for outdoor adventures, 
            competitions for competitive climbers, and training courses for skill development.
          </p>
        </div>

        <div className="events-grid">
          {events.map((event) => (
            <div key={event.id} className="event-card">
              <div className="event-image">
                <img src={event.image} alt={event.title} className="event-photo" />
                <div className="event-badges">
                  <div className={`event-type-badge ${getTypeColor(event.type)}`}>
                    {getTypeIcon(event.type)}
                    <span>{event.type.toUpperCase()}</span>
                  </div>
                  <span className={`difficulty-badge ${getDifficultyColor(event.difficulty)}`}>
                    {event.difficulty}
                  </span>
                </div>
              </div>
              
              <div className="event-content">
                <h3 className="event-title">{event.title}</h3>
                <p className="event-description">{event.description}</p>
                
                <div className="event-info">
                  <div className="event-detail">
                    <Calendar className="icon" />
                    <span>{event.date}</span>
                  </div>
                  <div className="event-detail">
                    <MapPin className="icon" />
                    <span>{event.location}</span>
                  </div>
                  
                  {renderEventSpecificInfo(event)}
                </div>

                <div className="event-footer">
                  <div className="event-pricing">
                    <span className="price">{event.price}</span>
                  </div>
                  
                  <button 
                    onClick={() => handleRegister(event)}
                    disabled={event.participants >= event.maxParticipants}
                    className={`register-btn ${event.participants >= event.maxParticipants ? 'disabled' : ''}`}
                  >
                    {event.participants >= event.maxParticipants ? 'Event Full' : 'Register Now'}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Footer */}
      <footer className="footer">
        <div className="footer-content">
          <div className="footer-brand">
            <Mountain className="footer-icon" />
            <h3>Polish Climbing Association</h3>
          </div>
          <p className="footer-tagline">Your gateway to extraordinary climbing experiences</p>
          <div className="footer-contact">
            <span>📧 info@polishclimbingassociation.com</span>
            <span>📞 (+48) 123-123-123</span>
            <span>📍 Warsaw, Poland</span>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Events;