import Events from './pages/Events'

function App() {
  return (
      <Events />
  )
}

export default App
